﻿namespace Instagraph.Data
{
    internal class Configuration
    {
        internal static string ConnectionString => "Server=.;Database=Instagraph;Integrated Security=True;";
    }
}
