﻿using System;

namespace Mapping.Data
{
    public class Configuration
    {
        public const string connenctionString = @"Server=(localdb)\MSSQLLocalDB;Database=Employees;Integrated Security=true";
    }
}
