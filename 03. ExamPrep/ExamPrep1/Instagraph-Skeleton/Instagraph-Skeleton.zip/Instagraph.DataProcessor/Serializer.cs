﻿using System;

using Instagraph.Data;

namespace Instagraph.DataProcessor
{
    public class Serializer
    {
        public static string ExportUncommentedPosts(InstagraphContext context)
        {
            throw new NotImplementedException();
        }

        public static string ExportPopularUsers(InstagraphContext context)
        {
            throw new NotImplementedException();
        }

        public static string ExportCommentsOnPosts(InstagraphContext context)
        {
            throw new NotImplementedException();
        }
    }
}
