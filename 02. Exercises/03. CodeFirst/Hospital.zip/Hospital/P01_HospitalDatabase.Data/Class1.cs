﻿using System;

namespace P01_HospitalDatabase.Data
{
    public class Class1
    {
    }
}
