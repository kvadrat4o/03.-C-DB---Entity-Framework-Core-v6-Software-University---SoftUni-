﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P01_HospitalDatabase.Data.Data
{
    class Configuration
    {
        public const string connectionString = @"Server=(localdb)\MSSQLLocalDB;DataBase=Hospital;Integrated Security=True";
    }
}
