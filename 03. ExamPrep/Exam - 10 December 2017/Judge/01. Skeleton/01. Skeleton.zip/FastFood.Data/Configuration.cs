namespace FastFood.Data
{
	public static class Configuration
	{
		public static string ConnectionString = @"Server=(localdb)\MSSQLLocalDB;Database=FastFood;Trusted_Connection=True";
	}
}