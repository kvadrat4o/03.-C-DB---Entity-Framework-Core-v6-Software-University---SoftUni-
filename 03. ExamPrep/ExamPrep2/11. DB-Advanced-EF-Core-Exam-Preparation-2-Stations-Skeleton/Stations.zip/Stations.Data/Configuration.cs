namespace Stations.Data
{
	public static class Configuration
	{
		public static string ConnectionString = @"Server=(localdb)\MSSQLLocalDB;Database=Stations;Trusted_Connection=True";
	}
}