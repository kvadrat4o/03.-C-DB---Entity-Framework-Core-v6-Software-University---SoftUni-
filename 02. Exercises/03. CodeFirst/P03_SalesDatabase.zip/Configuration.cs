﻿
namespace P03_SalesDatabase
{
    public class Configuration
    {
        public const string configurationString = "Server=.;Database=Sales;Integrated Security=True";
    }
}
