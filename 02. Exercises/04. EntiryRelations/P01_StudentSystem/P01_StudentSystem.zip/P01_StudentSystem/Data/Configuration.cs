﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P01_StudentSystem.Data
{
    public class Configuration
    {
        public const string connectionString = @"Server=(localdb)\MSSQLLocalDB;Database=StudentSystem;Integrated Security = true";
    }
}
