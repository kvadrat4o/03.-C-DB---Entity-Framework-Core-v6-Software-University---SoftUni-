﻿using System;

namespace P03_FootballBetting.Data
{
    public class Configuration
    {
        public const string connectionString = @"Server=TECHSUPPORT-PC2\SQLEXPRESS01;Database=FootballBookmakerSystem;Integrated Security=true";
    }
}
