﻿namespace Instagraph.DataProcessor.DtoModels
{
    public class PopularUserDto
    {
        public string Username { get; set; }
        public int Followers { get; set; }
    }
}
