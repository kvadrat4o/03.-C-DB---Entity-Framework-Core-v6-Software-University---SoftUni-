﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P02_DatabaseFirst.Data
{
    class Configuration

    {
        public const string connectionString = @"Server=(localdb)\MSSQLLocalDB;Database=SoftUni;Integrated Security = True";
    }
}
